import "./styles/About.css";

const About = () => {
  return (
    <div className="about-section" id="about">
      <div className="about-me">
        <h3 className="title">About Me</h3>
        <p className="para">
          I'm a Digital Marketing specialist and PGDM student based in Gurugram,
          India, with hands-on experience in SEO, performance marketing, and AI
          automation. I've helped brands grow their organic reach, manage paid
          campaigns, and leverage cutting-edge AI tools to streamline digital
          workflows — turning data into actionable strategies that drive real
          results.
        </p>
      </div>
    </div>
  );
};

export default About;

import "./styles/Career.css";

const Career = () => {
  return (
    <div className="career-section section-container">
      <div className="career-container">
        <h2>
          My career <span>&</span>
          <br /> experience
        </h2>
        <div className="career-info">
          <div className="career-timeline">
            <div className="career-dot"></div>
          </div>

          <div className="career-info-box">
            <div className="career-info-in">
              <div className="career-role">
                <h4>Digital Marketing Intern</h4>
                <h5>OriginCore Tech</h5>
              </div>
              <h3>2025</h3>
            </div>
            <p>
              Executed SEO strategies, managed Google Ads campaigns, handled
              Amazon Seller Account, and grew brand's Instagram presence —
              leveraging GA4, Search Console, Tag Manager, and Microsoft
              Clarity.
            </p>
          </div>

          <div className="career-info-box">
            <div className="career-info-in">
              <div className="career-role">
                <h4>Freelance Video Editor</h4>
                <h5>Self-Employed</h5>
              </div>
              <h3>2024</h3>
            </div>
            <p>
              Produced high-impact Instagram Reels and short-form content using
              DaVinci Resolve, CapCut, and Filmora — from ideation to final
              publish, integrating trending music and transitions to boost
              engagement.
            </p>
          </div>

          <div className="career-info-box">
            <div className="career-info-in">
              <div className="career-role">
                <h4>Management Trainee – Digital Marketing</h4>
                <h5>Ken Research</h5>
              </div>
              <h3>NOW</h3>
            </div>
            <p>
              Built high-quality backlinks, executed On-Page & Off-Page SEO,
              monitored performance via GA4 & GSC, and implemented AI
              automation workflows using Claude and N8N.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Career;

import "./styles/Work.css";
import WorkImage from "./WorkImage";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "../gsap-shims/useGSAP";

gsap.registerPlugin(ScrollTrigger);

const projects = [
  {
    name: "Ken Research SEO",
    category: "SEO / Link Building",
    tools: "GA4, GSC, SEMrush, N8N",
    image: "/images/placeholder.webp",
  },
  {
    name: "OriginCore Growth",
    category: "Performance Marketing",
    tools: "Google Ads, GA4, Tag Manager, Clarity",
    image: "/images/placeholder.webp",
  },
  {
    name: "Amazon Store Optimisation",
    category: "E-Commerce SEO",
    tools: "Amazon Seller Central, Keyword Research",
    image: "/images/placeholder.webp",
  },
  {
    name: "AI Workflow Automation",
    category: "AI Automation",
    tools: "Claude, N8N, Mailchimp, ChatGPT",
    image: "/images/placeholder.webp",
  },
  {
    name: "Instagram Brand Growth",
    category: "Social Media Marketing",
    tools: "Meta Business Suite, Canva, Microsoft Designer",
    image: "/images/placeholder.webp",
  },
  {
    name: "Sansiddhi 2.0 Fest",
    category: "Event Digital Strategy",
    tools: "Canva, Adobe InDesign, Meta Ads",
    image: "/images/placeholder.webp",
  },
];

const Work = () => {
  useGSAP(() => {
    let translateX: number = 0;

    function setTranslateX() {
      const box = document.getElementsByClassName("work-box");
      const rectLeft = document.querySelector(".work-container")!.getBoundingClientRect().left;
      const rect = box[0].getBoundingClientRect();
      const parentWidth = box[0].parentElement!.getBoundingClientRect().width;
      let padding: number = parseInt(window.getComputedStyle(box[0]).padding) / 2;
      translateX = rect.width * box.length - (rectLeft + parentWidth) + padding;
    }

    setTranslateX();

    let timeline = gsap.timeline({
      scrollTrigger: {
        trigger: ".work-section",
        start: "top top",
        end: `+=${translateX}`,
        scrub: true,
        pin: true,
        id: "work",
      },
    });

    timeline.to(".work-flex", { x: -translateX, ease: "none" });

    return () => {
      timeline.kill();
      ScrollTrigger.getById("work")?.kill();
    };
  }, []);

  return (
    <div className="work-section" id="work">
      <div className="work-container section-container">
        <h2>
          My <span>Work</span>
        </h2>
        <div className="work-flex">
          {projects.map((project, index) => (
            <div className="work-box" key={index}>
              <div className="work-info">
                <div className="work-title">
                  <h3>0{index + 1}</h3>
                  <div>
                    <h4>{project.name}</h4>
                    <p>{project.category}</p>
                  </div>
                </div>
                <h4>Tools and features</h4>
                <p>{project.tools}</p>
              </div>
              <WorkImage image={project.image} alt={project.name} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Work;

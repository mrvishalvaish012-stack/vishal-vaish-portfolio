// Stub: replaces gsap-trial/ScrollSmoother with no-op
export class ScrollSmoother {
  static create(_opts: Record<string, unknown>) { return new ScrollSmoother(); }
  static refresh(_force?: boolean) {}
  scrollTop(_v?: number) {}
  scrollTo(_target: string, _smooth?: boolean, _pos?: string) {
    const el = document.querySelector(_target);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  }
  paused(_v: boolean) {}
}

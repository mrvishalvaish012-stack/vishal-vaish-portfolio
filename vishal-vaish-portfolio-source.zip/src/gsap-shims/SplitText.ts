// Stub: replaces gsap-trial/SplitText — splits text into word/char spans
export class SplitText {
  words: HTMLElement[] = [];
  chars: HTMLElement[] = [];
  lines: HTMLElement[] = [];

  constructor(targets: string | string[] | Element | Element[], opts?: { type?: string; linesClass?: string }) {
    const type = opts?.type ?? 'words';
    const selectors = Array.isArray(targets) ? targets : [targets];
    selectors.forEach((sel) => {
      const els: Element[] = typeof sel === 'string'
        ? Array.from(document.querySelectorAll(sel))
        : [sel as Element];
      els.forEach((el) => this._split(el as HTMLElement, type));
    });
  }

  private _split(el: HTMLElement, type: string) {
    const text = el.innerText;
    el.innerHTML = '';
    if (type.includes('chars')) {
      text.split('').forEach((ch) => {
        const span = document.createElement('span');
        span.style.display = 'inline-block';
        span.textContent = ch === ' ' ? '\u00a0' : ch;
        el.appendChild(span);
        this.chars.push(span);
      });
    } else {
      text.split(' ').forEach((word, i, arr) => {
        const span = document.createElement('span');
        span.style.display = 'inline-block';
        span.textContent = word + (i < arr.length - 1 ? '\u00a0' : '');
        el.appendChild(span);
        this.words.push(span);
      });
    }
  }

  revert() {}
}

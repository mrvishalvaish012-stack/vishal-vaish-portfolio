import { useEffect } from 'react';
export function useGSAP(fn: () => void | (() => void), deps?: unknown[]) {
  useEffect(fn, deps);
}
